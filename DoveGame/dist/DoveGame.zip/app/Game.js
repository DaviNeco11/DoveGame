document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM fully loaded and parsed');

    // Log do caminho atual da página
    console.log('Current pathname:', window.location.pathname);

    // Verifica se estamos na página usupag.html
    if (window.location.pathname.endsWith('usupag.html')) {
        console.log('Correct page detected');

        const gameBoard = document.getElementById('game-board');
        if (gameBoard) {
            console.log('Game board element found');

            // Adiciona o container do avião
            const airplaneContainer = document.createElement('div');
            airplaneContainer.id = 'airplane-container';
            gameBoard.appendChild(airplaneContainer);

            // Adiciona a imagem do avião
            const airplane = document.createElement('img');
            airplane.id = 'airplane';
            airplane.src = 'Imagens8bits/aviao-removebg-preview.png'; // Caminho da imagem do avião
            airplane.alt = 'Avião'; // Adiciona um texto alternativo para acessibilidade
            airplaneContainer.appendChild(airplane);

            // Adiciona a cabeça do personagem sobre o avião
            const characterHead = document.createElement('img');
            characterHead.id = 'character-head';
            characterHead.src = 'Imagens8bits/CabecaChefe1.png'; // Caminho da imagem da cabeça do personagem
            characterHead.alt = 'Cabeça do personagem'; // Adiciona um texto alternativo para acessibilidade
            airplaneContainer.appendChild(characterHead);

            // Adiciona evento de clique para mover o avião para a esquerda
            airplaneContainer.addEventListener('click', function() {
                const currentLeft = airplaneContainer.style.left ? parseInt(airplaneContainer.style.left) : 50;
                airplaneContainer.style.left = (currentLeft - 10) + '%'; // Move o avião 10% para a esquerda
            });

            // Adiciona log para verificar se a imagem está sendo carregada
            airplane.onload = function () {
                console.log('Imagem do avião carregada com sucesso.');
            };
            airplane.onerror = function () {
                console.error('Erro ao carregar a imagem do avião.');
            };
            characterHead.onload = function () {
                console.log('Imagem da cabeça do personagem carregada com sucesso.');
            };
            characterHead.onerror = function () {
                console.error('Erro ao carregar a imagem da cabeça do personagem.');
            };
        } else {
            console.error('Game board element not found');
        }
    } else {
        console.log('This is not the target page');
    }
});
