const selectedOptionId = sessionStorage.getItem('selectedOptionId');
        document.getElementById('selected-option').textContent = 'Você selecionou a opção com ID: ' + selectedOptionId;


        
const usuario = sessionStorage.getItem('usuario');
console.log(usuario, "SESSION AQUI");



